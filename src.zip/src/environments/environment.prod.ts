export const environment = {
  production: true,
  serverUrl: "http://localhost:8888/api/v1/"
};
